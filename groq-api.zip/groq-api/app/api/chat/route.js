// app/api/chat/route.js
// ─────────────────────────────────────────────────────────
// ENDPOINT: POST /api/chat
//
// Request body (JSON):
// {
//   "messages": [{ "role": "user", "content": "Hello!" }],
//   "system":   "You are a helpful assistant.",  // opsional
//   "model":    "llama3-70b-8192",               // opsional
//   "stream":   false,                           // opsional
//   "max_tokens": 1024                           // opsional
// }
//
// Response (JSON):
// {
//   "id": "...",
//   "model": "...",
//   "message": { "role": "assistant", "content": "..." },
//   "usage": { "prompt_tokens": N, "completion_tokens": N, "total_tokens": N }
// }
// ─────────────────────────────────────────────────────────

import { NextResponse } from "next/server";
import { getGroqClient, DEFAULT_MODEL } from "@/lib/groq";
import { validateApiKey } from "@/lib/auth";

// ── CORS headers (izinkan akses dari domain mana saja) ──────────────────────
const CORS_HEADERS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, x-api-key",
};

// Handle preflight OPTIONS request
export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS_HEADERS });
}

// ── MAIN HANDLER ────────────────────────────────────────────────────────────
export async function POST(request) {
  // 1. Validasi API key
  const auth = validateApiKey(request);
  if (!auth.valid) {
    return NextResponse.json(
      { error: auth.error },
      { status: 401, headers: CORS_HEADERS }
    );
  }

  // 2. Parse request body
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: "Invalid JSON body." },
      { status: 400, headers: CORS_HEADERS }
    );
  }

  // 3. Validasi field wajib
  const { messages, system, model, max_tokens, stream } = body;

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return NextResponse.json(
      { error: "Field 'messages' wajib diisi dan harus berupa array." },
      { status: 400, headers: CORS_HEADERS }
    );
  }

  // 4. Validasi format messages
  for (const msg of messages) {
    if (!["user", "assistant", "system"].includes(msg.role)) {
      return NextResponse.json(
        { error: `Role tidak valid: '${msg.role}'. Gunakan: user | assistant | system` },
        { status: 400, headers: CORS_HEADERS }
      );
    }
    if (typeof msg.content !== "string" || msg.content.trim() === "") {
      return NextResponse.json(
        { error: "Setiap message harus memiliki 'content' berupa string tidak kosong." },
        { status: 400, headers: CORS_HEADERS }
      );
    }
  }

  // 5. Bangun payload untuk Groq
  const groqPayload = {
    model:      model || DEFAULT_MODEL,
    messages:   system
                  ? [{ role: "system", content: system }, ...messages]
                  : messages,
    max_tokens: max_tokens || 1024,
    temperature: body.temperature ?? 0.7,
  };

  // 6. Panggil Groq API
  try {
    const groq = getGroqClient();

    // ── Mode STREAMING ──────────────────────────────────────
    if (stream === true) {
      const streamResponse = await groq.chat.completions.create({
        ...groqPayload,
        stream: true,
      });

      const encoder = new TextEncoder();
      const readableStream = new ReadableStream({
        async start(controller) {
          try {
            for await (const chunk of streamResponse) {
              const delta = chunk.choices[0]?.delta?.content || "";
              if (delta) {
                // Format: Server-Sent Events (SSE)
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta })}\n\n`));
              }
            }
            controller.enqueue(encoder.encode("data: [DONE]\n\n"));
          } finally {
            controller.close();
          }
        },
      });

      return new Response(readableStream, {
        headers: {
          ...CORS_HEADERS,
          "Content-Type":  "text/event-stream",
          "Cache-Control": "no-cache",
          "Connection":    "keep-alive",
        },
      });
    }

    // ── Mode NON-STREAMING (default) ────────────────────────
    const completion = await groq.chat.completions.create(groqPayload);
    const choice     = completion.choices[0];

    return NextResponse.json(
      {
        id:      completion.id,
        model:   completion.model,
        message: {
          role:    choice.message.role,
          content: choice.message.content,
        },
        finish_reason: choice.finish_reason,
        usage: completion.usage,
      },
      { status: 200, headers: CORS_HEADERS }
    );

  } catch (err) {
    // 7. Error handling spesifik dari Groq SDK
    console.error("[Groq Error]", err);

    // Rate limit
    if (err.status === 429) {
      return NextResponse.json(
        { error: "Rate limit Groq tercapai. Coba lagi beberapa detik." },
        { status: 429, headers: CORS_HEADERS }
      );
    }

    // Invalid model
    if (err.status === 400) {
      return NextResponse.json(
        { error: `Request tidak valid: ${err.message}` },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    // Groq API key salah
    if (err.status === 401) {
      return NextResponse.json(
        { error: "GROQ_API_KEY tidak valid." },
        { status: 500, headers: CORS_HEADERS }
      );
    }

    return NextResponse.json(
      { error: "Internal server error.", detail: err.message },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}
